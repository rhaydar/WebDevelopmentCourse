// change the color of the body element to #6f84a5
// use document.body


// change the display property of the <a> elements to be block
// use document.getElementsByTagName()


// change the font size of the first paragraph to be 20px
// use document.getElementById()


// change the color of the elements with class "sam" to rgb(24, 84, 69)
// use document.getElementsByClassName()


// change the color of the elements with class "angel" to rgb(77, 24, 84)
// use document.querySelectorAll()


// change the font size of the fourth paragraph to be 20px
// use document.querySelector()


// center all the paragraphs


// bonus: select the first paragraph using each of the five different
// methods
